Digilines
==========
- The minetest counterpart for bus systems like i2c, SPI, RS232, USB -


This mod adds digiline wires, an RTC (Real Time Clock), a light sensor as well as an LCD Screen.
Can be used together with the luacontroller from mesecons. See the luacontroller manual for more information.

Send "GET" to RTC or light sensor to retrieve Data, send any text to LCD to display it.
Select channel by right-clicking items.

License:
  Code: LGPL
  Textures: WTFPL
