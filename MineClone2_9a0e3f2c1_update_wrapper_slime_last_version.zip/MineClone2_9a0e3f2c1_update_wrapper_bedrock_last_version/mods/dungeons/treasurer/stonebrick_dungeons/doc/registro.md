# Registro dei cambiamenti
Tutti i cambiamenti degni di nota per questo progetto verranno
documentati in questo file.

Questo formato è basato su [Keep a Changelog](https://keepachangelog.com/it-IT/1.0.0/)
e questo progetto si attiene al [Versionamento Semantico](https://semver.org/lang/it/).


## [Non rilasciato]

	- Non sono previste aggiunte ulteriori.


## [0.2.2] - 2018-05-13
### Rimozioni

	- variabile modpath inutile



## [0.2.1] - 2018-04-21
### Aggiunte

	- ../doc/


### Modifiche

	- depends.txt aggiunta dipendenza mancante su "stairs"
